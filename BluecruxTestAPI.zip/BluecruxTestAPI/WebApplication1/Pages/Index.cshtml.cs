﻿using BluecruxTest.Biz.DTO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Threading.Tasks;

namespace WebApplication1.Pages
{
    public class IndexModel : PageModel
    {
        static HttpClient client = new HttpClient();

        public List<PersonDTO> PersonDTOs { get; set; }

        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;

            client.BaseAddress = new Uri("https://localhost:7128/");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json"));
        }

        public async Task OnGet()
        {
            var persons = new List<PersonDTO>();

            var response = await client.GetAsync("Person");

            if (response.IsSuccessStatusCode)
            {
                persons = await response.Content.ReadFromJsonAsync<List<PersonDTO>>();
            }

            PersonDTOs = persons;
        }
    }
}