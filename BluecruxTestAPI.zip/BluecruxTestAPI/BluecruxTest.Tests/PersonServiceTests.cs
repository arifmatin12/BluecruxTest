﻿using Microsoft.Extensions.Logging;
using Moq;
using Xunit.Abstractions;
using Xunit;
using BluecruxTest.DataAccess;
using BluecruxTest.Biz.DTO;
using BluecruxTest.Biz;

namespace BluecruxTest.Tests
{
    public class PersonServiceTests
    {
        readonly ILogger<PersonServiceTests> _logger;
        private LoggerFactory _loggerFactory;

        private readonly Mock<TestDbContext> _contextMock = new();

        public PersonServiceTests()
        { }

        [Fact]
        public async Task GetAll_Person_Test()
        {
            var sut = new PersonService(_contextMock);

            PersonDTO person = new PersonDTO()
            {
                ID = 1,
                Name = "Arif",
                Age = 26,
                Gender = "Male",
                Height = 1.55m,
            };

            //Setup
            _contextMock.Setup(x => x.Person(It.IsAny<string>()))
                .Returns();

            var resp = sut.GetAll();

            Assert.Equal(person.Name, resp);
        }
    }
}