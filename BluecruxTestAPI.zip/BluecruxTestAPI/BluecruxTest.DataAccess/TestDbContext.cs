﻿using Microsoft.EntityFrameworkCore;
using System.Data.SqlClient;

namespace BluecruxTest.DataAccess
{
    public class TestDbContext : DbContext
    {

        public TestDbContext(DbContextOptions<TestDbContext> options)
          : base(options)
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(@"Server=localhost;Database=BluecruxTest;Trusted_Connection=True;Encrypt=False;",
                  sqlServerOptionsAction: sqlOptions =>
                  {
                      sqlOptions.EnableRetryOnFailure(
                          maxRetryCount: 5,
                          maxRetryDelay: TimeSpan.FromSeconds(10),
                          errorNumbersToAdd: null);
                  });

            }
        }
        public DbSet<Person> Person { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Person>(entity =>
            {
                entity.Property(e => e.ID).IsRequired();
                entity.Property(e => e.Name);
                entity.Property(e => e.Gender);
                entity.Property(e => e.Age);
                entity.Property(e => e.Height);
            });
        }
    }
}