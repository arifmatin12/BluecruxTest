﻿using BluecruxTest.Biz.DTO;

namespace BluecruxTest.Biz
{
    public interface IPersonService
    {
        List<PersonDTO> GetAll();

        PersonDTO CreatePerson(PersonDTO person);

        int DeletePerson(int ID);

        PersonDTO UpdatePerson(PersonDTO person);
    }
}