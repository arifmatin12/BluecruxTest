﻿using BluecruxTest.Biz.DTO;
using BluecruxTest.DataAccess;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BluecruxTest.Biz
{
    public class PersonService : IPersonService
    {
        private readonly TestDbContext _context;

        public PersonService(TestDbContext testDbContext)
        {
            _context = testDbContext;
        }

        public List<PersonDTO> GetAll()
        {
            var persons = _context.Person.FromSqlRaw("SELECT * FROM dbo.Person");

            var personsList = new List<PersonDTO>();

            foreach (var person in persons)
            {
                personsList.Add(person.ToPerson());
            }

            return personsList;
        }

        public PersonDTO CreatePerson(PersonDTO person)
        {
            var response =  _context.Person.FromSqlRaw($"insert dbo.Person values('{person.Name}','{person.Gender}',{person.Height},{person.Age})");
            _context.SaveChanges();

            var newPerson = _context.Person.FromSqlRaw("SELECT TOP 1 * FROM dbo.Person ORDER BY ID DESC");

            return newPerson.First().ToPerson();

        }

        public int DeletePerson(int ID)
        {
            var response = _context.Person.FromSqlRaw($"delete from dbo.Person where ID = {ID}");
            _context.SaveChanges();

            return ID;
        }

        public PersonDTO UpdatePerson(PersonDTO person)
        {
            var response = _context.Person.FromSqlRaw($"UPDATE dbo.Person SET Name = '{person.Name}', Gender = '{person.Gender}', Height = {person.Height}, Age = {person.Age} WHERE ID = {person.ID}");
            _context.SaveChanges();

            return person;
        }
    }
}
