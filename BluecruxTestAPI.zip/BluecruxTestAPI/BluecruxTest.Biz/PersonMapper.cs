﻿using BluecruxTest.Biz.DTO;
using BluecruxTest.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BluecruxTest.Biz
{
    public static class PersonMapper
    {
        public static PersonDTO ToPerson(this Person person)
        {
            if (person == null)
            {
                throw new ArgumentNullException($"The {nameof(person)} parameter cannot be null in {nameof(ToPerson)}.");
            }

            return new PersonDTO
            {
                ID = person.ID,
                Name = person.Name,
                Age = person.Age,
                Gender = person.Gender,
                Height = person.Height,
            };
        }
    }
}
