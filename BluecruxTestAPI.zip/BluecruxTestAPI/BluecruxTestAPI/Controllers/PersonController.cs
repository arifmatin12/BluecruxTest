using BluecruxTest.Biz;
using BluecruxTest.Biz.DTO;
using BluecruxTest.DataAccess;
using Microsoft.AspNetCore.Mvc;

namespace BluecruxTestAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PersonController : ControllerBase
    {
        private readonly IPersonService _personService;
        private readonly ILogger<PersonController> _logger;

        public PersonController(ILogger<PersonController> logger, 
            IPersonService personService)
        {
            _logger = logger;
            _personService = personService;
        }

        [HttpGet]
        public ActionResult<List<PersonDTO>> Get()
        {
            try
            {
                return _personService.GetAll(); 
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        [HttpPost]
        public ActionResult<PersonDTO> Create([FromForm] PersonDTO person)
        {
            try
            {
                var newPerson = _personService.CreatePerson(person);
                return newPerson;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        [HttpPut]
        public ActionResult<PersonDTO> Update([FromForm] PersonDTO person)
        {
            try
            {
                var response = _personService.UpdatePerson(person);
                return response;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        [HttpDelete]
        public ActionResult<int> Delete(int ID)
        {
            try
            {
                var response = _personService.DeletePerson(ID);
                return response;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}